
import axios from 'axios';


const API_URL = 'http://localhost:5000/api';

export const signupUser = async (credentials) => {
  const response = await axios.post(`${API_URL}/signup`, credentials);
  return response.data;
};

export const loginUser = async (credentials) => {
  const response = await axios.post(`${API_URL}/login`, credentials);
  return response.data; 
};


export const fetchUsers = () => {
  return axios.get(`${API_URL}/users`);
};

export const createUser = (userData) => {
  return axios.post(`${API_URL}/users`, userData);
};

export const fetchPlaylists = () => {
  return axios.get(`${API_URL}/playlists`);
};

export const createPlaylist = (playlistData) => {
  return axios.post(`${API_URL}/playlists`, playlistData);
};

export const fetchSongs = () => {
  return axios.get(`${API_URL}/songs`);
};

export const createSong = (songData) => {
  return axios.post(`${API_URL}/songs`, songData);
};



