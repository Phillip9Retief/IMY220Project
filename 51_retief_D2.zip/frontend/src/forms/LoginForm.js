import React, { useState } from 'react';
import './FormStyles.css';
import { loginUser } from '../api'; // Import the API function
import { useNavigate } from 'react-router-dom'; // Import useNavigate

function LoginForm({ onLogin }) {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate(); // Get the navigate function

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value
    }));
  };

  const validateForm = () => {
    let newErrors = {};
    if (!formData.username) newErrors.username = "Username is required";
    if (!formData.password) newErrors.password = "Password is required";
    else if (formData.password.length < 6) newErrors.password = "Password must be at least 6 characters";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission
    if (validateForm()) {
      try {
        const user = await loginUser(formData); // Call the API to login
        console.log("Login successful:", user); // Debugging statement
        
        // Save token and userId in local storage
        localStorage.setItem('token', user.token); // Assuming your API returns a token
        localStorage.setItem('userId', user.userId); // Assuming your API returns a userId
  
        onLogin(user); // Handle successful login in the parent component
        navigate('/home'); // Redirect to home page after login
      } catch (error) {
        console.error('Login failed:', error); // Log the error for debugging
        setErrors({ ...errors, general: "Invalid username or password" }); // Set general error message
      }
    }
  };
  

  return (
    <div className="form-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit} className="form">
        <div className="form-group">
          <label htmlFor="login-username">Username:</label>
          <input
            type="text"
            id="login-username" // Updated to be unique
            name="username"
            value={formData.username}
            onChange={handleChange}
            className={`form-input ${errors.username ? 'error-input' : ''}`}
          />
          {errors.username && <span className="error">{errors.username}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="login-password">Password:</label>
          <input
            type="password"
            id="login-password" // Updated to be unique
            name="password"
            value={formData.password}
            onChange={handleChange}
            className={`form-input ${errors.password ? 'error-input' : ''}`}
          />
          {errors.password && <span className="error">{errors.password}</span>}
        </div>
        {errors.general && <span className="error">{errors.general}</span>}
        <button type="submit" className="submit-button">Login</button>
      </form>
    </div>
  );
}

export default LoginForm;
