// AddSongForm.js
import React, { useState } from 'react';

function AddSongForm({ onAddSong }) {
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [image, setImage] = useState('');

// In AddSongForm.js
const handleSubmit = (e) => {
  e.preventDefault();
  const newSong = { title, artist, image }; // Adjust this based on your form fields
  onAddSong(newSong); // Call the passed function to add the song to the feed
};


  return (
    <form onSubmit={handleSubmit} className="add-song-form">
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Song Title"
      />
      <input
        type="text"
        value={artist}
        onChange={(e) => setArtist(e.target.value)}
        placeholder="Artist"
      />
      <input
        type="text"
        value={image}
        onChange={(e) => setImage(e.target.value)}
        placeholder="Image URL"
      />
      <button type="submit">Add Song</button>
    </form>
  );
}

export default AddSongForm;
