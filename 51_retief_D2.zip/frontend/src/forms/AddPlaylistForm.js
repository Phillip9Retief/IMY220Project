// AddPlaylistForm.js
import React, { useState } from 'react';

function AddPlaylistForm({ onAddPlaylist }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const newPlaylist = { title, description };
    onAddPlaylist(newPlaylist);
    setTitle('');
    setDescription('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Playlist Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <textarea
        placeholder="Playlist Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        required
      ></textarea>
      <button type="submit">Create Playlist</button>
    </form>
  );
}

export default AddPlaylistForm;
