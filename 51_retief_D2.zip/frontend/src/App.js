import React, { useState } from 'react';
import { Route, Routes } from 'react-router-dom';
import HomePage from './pages/HomePage';
import ProfilePage from './pages/ProfilePage';
import PlaylistPage from './pages/PlaylistPage';
import LoginForm from './forms/LoginForm';
import SignupForm from './forms/SignUpForm';
import SplashPage from './pages/SplashPage'; 
import Header from './components/Header';

function App() {
  const [user, setUser] = useState(null); // State to manage logged-in user

  const handleLogin = (userData) => {
    setUser(userData); // Set user data on successful login
    localStorage.setItem('token', userData.token); // Store the token in local storage
  };

  const handleSignUp = (userData) => {
    setUser(userData); // Set user data on successful sign-up
    localStorage.setItem('token', userData.token); // Store the token in local storage
  };

  const handleLogout = () => {
    setUser(null); // Clear user data on logout
    localStorage.removeItem('token'); // Remove token from local storage
  };

  return (
    <>
      <Header onLogout={handleLogout} />
      <Routes>
        <Route path="/" element={<SplashPage onLogin={handleLogin} onSignUp={handleSignUp} />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/profile/:id" element={<ProfilePage />} /> {/* Corrected here */}
        <Route path="/playlist/:id" element={<PlaylistPage />} />
        <Route path="/login" element={<LoginForm onLogin={handleLogin} />} />
        <Route path="/signup" element={<SignupForm onSignUp={handleSignUp} />} />
      </Routes>
    </>
  );
}

export default App;
