import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import '../SiteStyles.css';

// Profile Component
function Profile({ user, onEdit }) {
  return (
    <div className="profile-card">
      <img src={user.profileImage} alt={user.username} className="profile-pic" />
      <h2>{user.username}</h2>
      <p>{user.bio || "No bio available."}</p>
      <button onClick={onEdit} className="edit-button">Edit Profile</button>
    </div>
  );
}

// Edit Profile Component
function EditProfile({ user, onSave, onCancel }) {
  const [editedUser, setEditedUser] = useState(user);

  const handleChange = (e) => {
    setEditedUser({ ...editedUser, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(editedUser);
  };

  return (
    <form onSubmit={handleSubmit} className="edit-profile-form">
      <input
        type="text"
        name="username"
        value={editedUser.username}
        onChange={handleChange}
        placeholder="Username"
      />
      <textarea
        name="bio"
        value={editedUser.bio || ''}
        onChange={handleChange}
        placeholder="Bio"
      />
      <div className="button-group">
        <button type="submit" className="save-button">Save</button>
        <button type="button" onClick={onCancel} className="cancel-button">Cancel</button>
      </div>
    </form>
  );
}

// Media List Component
function MediaList({ items, type }) {
  return (
    <div className="media-list">
      <h3>{type === 'playlist' ? 'Playlists' : 'Songs'}</h3>
      <div className="feed">
        {items.length > 0 ? (
          items.map((item, index) => (
            <div key={index} className="feed-item">
              <img src={item.image} alt={item.title} style={{ width: '100px', height: '100px' }} />
              <h4>{item.title}</h4>
              {type === 'song' && <p>Artist: {item.artist}</p>}
            </div>
          ))
        ) : (
          <p>No {type === 'playlist' ? 'playlists' : 'songs'} available.</p>
        )}
      </div>
    </div>
  );
}

// Follow List Component
function FollowList({ users, type }) {
  return (
    <div className="follow-list">
      <h3>{type === 'followers' ? 'Followers' : 'Following'}</h3>
      <div className="user-grid">
        {users.length > 0 ? (
          users.map((user, index) => (
            <div key={index} className="user-preview">
              <img src={user.profileImage} alt={user.username} />
              <p>{user.username}</p>
            </div>
          ))
        ) : (
          <p>No {type === 'followers' ? 'followers' : 'following'} available.</p>
        )}
      </div>
    </div>
  );
}

// Create Playlist Component
function CreatePlaylist({ onCreatePlaylist }) {
  const [playlistName, setPlaylistName] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onCreatePlaylist(playlistName);
    setPlaylistName('');
  };

  return (
    <form onSubmit={handleSubmit} className="create-playlist-form">
      <input
        type="text"
        value={playlistName}
        onChange={(e) => setPlaylistName(e.target.value)}
        placeholder="Enter playlist name"
      />
      <button type="submit" className="create-button">Create Playlist</button>
    </form>
  );
}

// Main ProfilePage Component
function ProfilePage() {
  const { id } = useParams(); // Extract ID from URL
  const [isEditing, setIsEditing] = useState(false);
  const [user, setUser] = useState(null);
  const [playlists, setPlaylists] = useState([]);
  const [songs, setSongs] = useState([]);
  const [followers, setFollowers] = useState([]);
  const [following, setFollowing] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch(`/api/users/${id}`); // Replace with your API endpoint
        if (!response.ok) {
          throw new Error('Failed to fetch user data');
        }
        const userData = await response.json();
        setUser(userData); // Assuming your API returns user data directly
        setPlaylists(userData.playlists || []);
        setSongs(userData.songs || []);
        setFollowers(userData.followers || []);
        setFollowing(userData.following || []);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false); // Stop loading whether success or error
      }
    };

    fetchUserData();
  }, [id]);

  const handleEditProfile = () => setIsEditing(true);
  const handleCancelEdit = () => setIsEditing(false);
  const handleSaveProfile = (editedUser) => {
    setUser(editedUser);
    setIsEditing(false);
  };

  const handleCreatePlaylist = (name) => {
    setPlaylists([...playlists, { title: name, image: 'https://via.placeholder.com/100?text=New+Playlist' }]);
  };

  if (loading) return <p>Loading...</p>; // Show loading state
  if (error) return <p>Error: {error}</p>; // Handle any errors

  return (
    <div className="container profile-page">
      <h1>Profile Page</h1>
      {isEditing ? (
        <EditProfile user={user} onSave={handleSaveProfile} onCancel={handleCancelEdit} />
      ) : (
        <Profile user={user} onEdit={handleEditProfile} />
      )}
      <CreatePlaylist onCreatePlaylist={handleCreatePlaylist} />
      <MediaList items={playlists} type="playlist" />
      <MediaList items={songs} type="song" />
      <FollowList users={followers} type="followers" />
      <FollowList users={following} type="following" />
    </div>
  );
}

export default ProfilePage;
