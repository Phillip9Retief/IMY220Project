import React from 'react';
import LoginForm from '../forms/LoginForm';
import SignUpForm from '../forms/SignUpForm';
import './SplashPage.css';

function SplashPage({ onLogin, onSignUp }) {
  return (
    <div>
      <h1>Welcome to Tune Union</h1>
      <LoginForm onLogin={onLogin} />  {/* Make sure onLogin is passed */}
      <SignUpForm onSignUp={onSignUp} /> {/* Make sure onSignUp is passed */}
    </div>
  );
}

export default SplashPage;
