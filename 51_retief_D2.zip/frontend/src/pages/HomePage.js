import React, { useState, useEffect } from 'react';
import '../SiteStyles.css';
import AddSongForm from '../components/AddSongForm';
import { debounce } from 'lodash';

function SearchInput({ onSearch }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchType, setSearchType] = useState('song'); // Default search type

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch(searchTerm, searchType);
  };

  return (
    <form onSubmit={handleSubmit} className="search-container animate-fade-in">
      <input
        type="text"
        className="search-input"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder="Search for songs, playlists, or users..."
      />
      <select
        className="search-select"
        value={searchType}
        onChange={(e) => setSearchType(e.target.value)}
      >
        <option value="song">Songs</option>
        <option value="playlist">Playlists</option>
        <option value="user">Users</option>
      </select>
      <button type="submit" className="search-button">Search</button>
    </form>
  );
}

function FeedItem({ type, title, artist, image, userId, onFriend }) {
  const handleFriendClick = () => {
    onFriend(userId); // Pass the friend's userId
  };

  return (
    <div className="feed-item animate-fade-in">
      <div className="image-container">
        <img src={image} alt={title} />
        {type === 'song' ? (
          <div className="overlay-icon">
            <i className="fa fa-play-circle"></i>
          </div>
        ) : type === 'playlist' ? (
          <div className="overlay-icon">
            <i className="fa fa-music"></i>
          </div>
        ) : null}
      </div>
      <h3>{title}</h3>
      {type === 'song' && <p>Artist: {artist}</p>}
      {type === 'user' && (
        <button className="action-button" onClick={handleFriendClick}>
          Add Friend
        </button>
      )}
      {type === 'song' && <button className="action-button">Play</button>}
      {type === 'playlist' && <button className="action-button">View Playlist</button>}
    </div>
  );
}

function Feed({ items, onFriend }) {
  return (
    <div className="feed">
      {items.map((item, index) => (
        <FeedItem key={index} {...item} onFriend={onFriend} />
      ))}
    </div>
  );
}

function HomePage() {
  const [feedItems, setFeedItems] = useState([]);
  const [searchResults, setSearchResults] = useState([]);

  // Assume currentUserId is fetched from localStorage or a context
  const currentUserId = localStorage.getItem('currentUserId'); // Replace this with your actual logic to get current user ID

  const handleSearch = debounce(async (searchTerm, searchType) => {
    try {
      const response = await fetch(`/api/search?query=${searchTerm}&type=${searchType}`);
      if (!response.ok) {
        throw new Error('Search request failed');
      }
      const data = await response.json();
      const formattedResults = data.map((item) => ({
        type: searchType,
        title: searchType === 'song' ? item.songs[0]?.name : item.name,
        artist: item?.songs?.[0]?.artist || '',
        image: 'https://via.placeholder.com/200x200?text=' + (searchType === 'song' ? item.songs[0]?.name : item.name),
        userId: searchType === 'user' ? item.id : null, // Store userId for friend request
      }));
      setSearchResults(formattedResults);
    } catch (error) {
      console.error('Error fetching search results:', error);
    }
  },300);

  const handleFriend = async (friendId) => {
    try {
      // Ensure currentUserId is defined
      if (!currentUserId) {
        throw new Error('currentUserId is not available');
      }

      const response = await fetch(`http://localhost:5000/api/users/${currentUserId}/friends/${friendId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
      });

      if (!response.ok) {
        throw new Error('Friend request failed');
      }

      const result = await response.json();
      console.log('Friend added successfully:', result);
    } catch (error) {
      console.error('Error sending friend request:', error);
    }
  };

  const addSongToFeed = (newSong) => {
    setFeedItems((prevItems) => [newSong, ...prevItems]);
  };

  useEffect(() => {
    document.title = 'Tune Union - Home';
    
    const fetchFeedItems = async () => {
      try {
        const response = await fetch('/api/feed'); // Update to your actual feed endpoint
        if (!response.ok) throw new Error('Failed to fetch feed items');
        const data = await response.json();
        setFeedItems(data);
      } catch (error) {
        console.error('Error fetching feed items:', error);
      }
    };
  
    fetchFeedItems();
  }, []);
  

  return (
    <div className="container home-page">
      <h1 className="animate-fade-in">Welcome to Tune Union</h1>
      <SearchInput onSearch={handleSearch} />
      <AddSongForm onAddSong={addSongToFeed} /> {/* Pass handler to AddSongForm */}
      <Feed items={searchResults.length > 0 ? searchResults : feedItems} onFriend={handleFriend} />
    </div>
  );
}

export default HomePage;
