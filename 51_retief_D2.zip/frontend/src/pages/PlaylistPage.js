import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import '../SiteStyles.css';

// Playlist Item Component
function PlaylistItem({ playlist }) {
  return (
    <div className="playlist-item">
      <h3>{playlist.title}</h3>
      <p>Created by: {playlist.creator}</p>
    </div>
  );
}

// Playlist List Component
function PlaylistList({ playlists }) {
  return (
    <div className="playlist-list">
      {playlists.map((playlist) => (
        <Link to={`/playlists/${playlist.id}`} key={playlist.id}>
          <PlaylistItem playlist={playlist} />
        </Link>
      ))}
    </div>
  );
}

// Edit Playlist Component
function EditPlaylist({ playlist, onSave, onCancel }) {
  const [editedPlaylist, setEditedPlaylist] = useState(playlist);

  const handleChange = (e) => {
    setEditedPlaylist({ ...editedPlaylist, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(editedPlaylist);
  };

  return (
    <form onSubmit={handleSubmit} className="edit-playlist-form">
      <input
        type="text"
        name="title"
        value={editedPlaylist.title}
        onChange={handleChange}
        placeholder="Playlist Title"
        required
      />
      <textarea
        name="description"
        value={editedPlaylist.description}
        onChange={handleChange}
        placeholder="Playlist Description"
        required
      />
      <div className="button-group">
        <button type="submit" className="save-button">Save</button>
        <button type="button" onClick={onCancel} className="cancel-button">Cancel</button>
      </div>
    </form>
  );
}

// Song Component
function Song({ song }) {
  return (
    <div className="song-item">
      <img src={song.coverArt} alt={song.title} className="song-cover" />
      <div className="song-info">
        <h4>{song.title}</h4>
        <p>{song.artist}</p>
      </div>
    </div>
  );
}

// Song List Component
function SongList({ songs }) {
  return (
    <div className="song-list">
      <h3>Songs in this Playlist</h3>
      {songs.length > 0 ? (
        songs.map((song, index) => <Song key={index} song={song} />)
      ) : (
        <p>No songs available in this playlist.</p>
      )}
    </div>
  );
}

// Add Song Form Component
function AddSongForm({ onAddSong }) {
  const [newSong, setNewSong] = useState({ title: '', artist: '', coverArt: '' });

  const handleChange = (e) => {
    setNewSong({ ...newSong, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddSong(newSong);
    setNewSong({ title: '', artist: '', coverArt: '' }); // Clear form after submission
  };

  return (
    <form onSubmit={handleSubmit} className="add-song-form">
      <input
        type="text"
        name="title"
        value={newSong.title}
        onChange={handleChange}
        placeholder="Song Title"
        required
      />
      <input
        type="text"
        name="artist"
        value={newSong.artist}
        onChange={handleChange}
        placeholder="Artist Name"
        required
      />
      <input
        type="text"
        name="coverArt"
        value={newSong.coverArt}
        onChange={handleChange}
        placeholder="Cover Art URL"
        required
      />
      <button type="submit" className="add-song-button">Add Song</button>
    </form>
  );
}

// Main PlaylistPage Component
function PlaylistPage() {
  const { id } = useParams(); // Get the playlist ID from URL
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [playlist, setPlaylist] = useState(null);
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userPlaylists, setUserPlaylists] = useState([]); // State for user's playlists
  const [loadingPlaylists, setLoadingPlaylists] = useState(true);
  const [playlistsError, setPlaylistsError] = useState(null);

  // Fetch user's playlists
  useEffect(() => {
    const fetchUserPlaylists = async () => {
      try {
        const response = await fetch(`/api/users/${userId}/playlists`);
        if (!response.ok) {
          throw new Error('Failed to fetch user playlists');
        }
        const data = await response.json();
        setUserPlaylists(data); // Set the user's playlists
      } catch (error) {
        setPlaylistsError(error.message);
      } finally {
        setLoadingPlaylists(false);
      }
    };

    fetchUserPlaylists();
  }, [id]);

  useEffect(() => {
    const fetchPlaylist = async () => {
      try {
        const response = await fetch(`/api/users/${userId}/playlists`);

        if (!response.ok) {
          throw new Error('Failed to fetch playlist');
        }
        const data = await response.json();
        setPlaylist(data);
        setSongs(data.songs || []); // Use an empty array if no songs
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPlaylist();
  }, [id]);

  const handleEditPlaylist = () => setIsEditing(true);
  const handleCancelEdit = () => setIsEditing(false);

  const handleSavePlaylist = async (editedPlaylist) => {
    try {
      
      const response = await fetch(`/api/playlists/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editedPlaylist),
      });

      if (!response.ok) {
        throw new Error('Failed to save playlist');
      }

      const updatedPlaylist = await response.json();
      setPlaylist(updatedPlaylist);
      setIsEditing(false);
    } catch (error) {
      setError(error.message);
    }
  };

  const handleDeletePlaylist = async () => {
    try {
      const response = await fetch(`/api/playlists/${playlist.id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });

      if (!response.ok) throw new Error('Failed to delete playlist');

      navigate('/'); // Redirect to home or playlists page after deletion
    } catch (error) {
      setError(error.message);
    }
  };

  const handleAddSong = async (newSong) => {
    try {
      const response = await fetch(`/api/playlists/${id}/songs`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newSong),
      });

      if (!response.ok) {
        throw new Error('Failed to add song to playlist');
      }

      const updatedSongs = await response.json(); // Assuming the response returns the updated songs
      setSongs(updatedSongs);
    } catch (error) {
      setError(error.message);
    }
  };

  if (loading) return <p>Loading playlist...</p>; // Show a loading state while fetching data
  if (error) return <p>Error: {error}</p>; // Handle any errors
  if (loadingPlaylists) return <p>Loading user playlists...</p>; // Loading state for user playlists
  if (playlistsError) return <p>Error fetching user playlists: {playlistsError}</p>; // Error for user playlists

  return (
    <div className="container playlist-page">
      <h1>{playlist.title}</h1>
      {isEditing ? (
        <EditPlaylist playlist={playlist} onSave={handleSavePlaylist} onCancel={handleCancelEdit} />
      ) : (
        <div>
          <PlaylistItem playlist={playlist} />
          <button onClick={handleEditPlaylist} className="edit-button">Edit Playlist</button>
          <button onClick={handleDeletePlaylist} className="delete-button">Delete Playlist</button>
        </div>
      )}
      <SongList songs={songs} />
      <AddSongForm onAddSong={handleAddSong} /> {/* Add song functionality */}
      <h2>User's Playlists</h2>
      <PlaylistList playlists={userPlaylists} /> {/* Display user's playlists */}
    </div>
  );
}

export default PlaylistPage;
