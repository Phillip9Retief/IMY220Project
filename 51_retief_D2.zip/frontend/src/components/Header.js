import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Header({ onLogout }) {
  const navigate = useNavigate(); // Get the navigate function
  const token = localStorage.getItem('token'); // Check if the user is authenticated
  const userId = localStorage.getItem('userId'); // Assume you store the user ID in local storage

  const handleLogout = () => {
    onLogout(); // Call the logout function passed down as a prop
    localStorage.removeItem('token'); // Remove the token from local storage
    localStorage.removeItem('userId'); // Optionally remove the user ID
    navigate('/'); // Redirect to the splash page or home
  };

  return (
    <nav className="navbar">
      <ul>
        {token ? ( // If the user is logged in
          <>
            <li><Link to="/home">Home</Link></li>
            <li>
              {/* Link to the profile with the actual user ID */}
              <Link to={`/profile/${userId}`}>Profile</Link>
            </li>
            <li><Link to={`/Playlist/${userId}`}>Playlists</Link></li>
            <li><button onClick={handleLogout}>Logout</button></li>
          </>
        ) : ( // If the user is not logged in
          <>
            <li><Link to="/login">Login</Link></li>
            <li><Link to="/signup">Sign Up</Link></li>
          </>
        )}
      </ul>
    </nav>
  );
}

export default Header;
