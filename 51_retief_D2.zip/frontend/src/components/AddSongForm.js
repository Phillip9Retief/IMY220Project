// AddSongForm.js
import React, { useState } from 'react';
import { createSong } from '../api'; // Import the createSong function

function AddSongForm({ onAddSong }) { // Accept onAddSong as a prop
  const [songData, setSongData] = useState({
    title: '',
    artist: '',
    albumArt: '',
    playlistId: '', // Include playlistId if needed
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSongData({ ...songData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const newSong = await createSong(songData); // Call the API to create a song
      onAddSong(newSong.data); // Call the passed function to update the feed
      setSongData({ title: '', artist: '', albumArt: '', playlistId: '' }); // Reset form
    } catch (error) {
      console.error('Error adding song:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="add-song-form">
      <input
        type="text"
        name="title"
        placeholder="Song Title"
        value={songData.title}
        onChange={handleChange}
        required
      />
      <input
        type="text"
        name="artist"
        placeholder="Artist Name"
        value={songData.artist}
        onChange={handleChange}
        required
      />
      <input
        type="text"
        name="albumArt"
        placeholder="Album Art URL"
        value={songData.albumArt}
        onChange={handleChange}
      />
      <input
        type="text"
        name="playlistId"
        placeholder="Playlist ID"
        value={songData.playlistId}
        onChange={handleChange}
        required
      />
      <button type="submit">Add Song</button>
    </form>
  );
}

export default AddSongForm;
