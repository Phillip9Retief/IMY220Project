const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const User = require('./models/users'); // User model
const Playlist = require('./models/playlists'); // Ensure you have this model defined

const app = express();

// Middleware to parse JSON request bodies
app.use(express.json());

// MongoDB connection string
const uri = 'mongodb+srv://u23616815:SIYkTURN65V4RKOt@maincluster.sdnkg.mongodb.net/TuneDB?retryWrites=true&w=majority';

// JWT secret key (ensure this is defined securely)
const JWT_SECRET = 'your_jwt_secret_key'; // Replace with your actual secret

// Function to connect to MongoDB using mongoose
mongoose.connect(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => {
    console.log("Connected to MongoDB with Mongoose");
})
.catch((err) => {
    console.error("Database connection error:", err);
});

// User signup route
app.post('/api/signup', async (req, res) => {
  const { name, username, email, password } = req.body;

  // Validate input fields
  if (!name || !username || !email || !password) {
    return res.status(400).json({ message: "All fields are required" });
  }

  try {
    const newUser = new User({ name, username, email, password });
    await newUser.save();
    res.status(201).json({ message: "User created successfully!", userId: newUser._id });
  } catch (error) {
    console.error("Signup error:", error);
    res.status(400).json({ message: "Error creating user", error: error.message });
  }
});

// User login route
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    // Use the comparePassword method on the User model instance
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '1h' });
    res.status(200).json({ message: "Login successful", token, userId: user._id });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// Create a new playlist
app.post('/api/playlists', async (req, res) => {
  const { name, description, userId } = req.body;

  try {
    const newPlaylist = new Playlist({ name, description, userId });
    const savedPlaylist = await newPlaylist.save();
    await User.findByIdAndUpdate(userId, { $push: { playlists: savedPlaylist._id } });
    res.status(201).json({ message: "Playlist created successfully!", playlistId: savedPlaylist._id });
  } catch (error) {
    console.error("Error creating playlist:", error);
    res.status(400).json({ message: "Error creating playlist", error: error.message });
  }
});

// Get user profile
app.get('/api/users/:userId', async (req, res) => {
  try {
    const user = await User.findById(req.params.userId).select('-password');
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ message: "Error fetching user", error: error.message });
  }
});

// Update user profile
app.put('/api/users/:userId', async (req, res) => {
  try {
    const updatedUser = await User.findByIdAndUpdate(req.params.userId, req.body, { new: true }).select('-password');
    res.json(updatedUser);
  } catch (error) {
    res.status(400).json({ message: "Error updating user", error: error.message });
  }
});

// Delete user profile
app.delete('/api/users/:userId', async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.userId);
    res.json({ message: "User deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting user", error: error.message });
  }
});

// Friend/Unfriend a user
app.post('/api/users/:userId/friends/:friendId', async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    const friend = await User.findById(req.params.friendId);

    if (!user || !friend) {
      return res.status(404).json({ message: "User not found" });
    }

    if (user.friends.includes(req.params.friendId)) {
      user.friends = user.friends.filter(id => id.toString() !== req.params.friendId);
      friend.friends = friend.friends.filter(id => id.toString() !== req.params.userId);
    } else {
      user.friends.push(req.params.friendId);
      friend.friends.push(req.params.userId);
    }

    await user.save();
    await friend.save();

    res.json({ message: "Friend status updated" });
  } catch (error) {
    res.status(500).json({ message: "Error updating friend status", error: error.message });
  }
});

// Get all playlists
app.get('/api/playlists', async (req, res) => {
  try {
    const playlists = await Playlist.find();
    res.json(playlists);
  } catch (error) {
    res.status(500).json({ message: "Error fetching playlists", error: error.message });
  }
});

// Get a specific playlist
app.get('/api/playlists/:playlistId', async (req, res) => {
  try {
    const playlist = await Playlist.findById(req.params.playlistId);
    if (!playlist) {
      return res.status(404).json({ message: "Playlist not found" });
    }
    res.json(playlist);
  } catch (error) {
    res.status(500).json({ message: "Error fetching playlist", error: error.message });
  }
});

// Update a playlist
app.put('/api/playlists/:playlistId', async (req, res) => {
  try {
    const updatedPlaylist = await Playlist.findByIdAndUpdate(req.params.playlistId, req.body, { new: true });
    res.json(updatedPlaylist);
  } catch (error) {
    res.status(400).json({ message: "Error updating playlist", error: error.message });
  }
});

// Delete a playlist
app.delete('/api/playlists/:playlistId', async (req, res) => {
  try {
    await Playlist.findByIdAndDelete(req.params.playlistId);
    res.json({ message: "Playlist deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting playlist", error: error.message });
  }
});

// Add a song to a playlist
app.post('/api/playlists/:playlistId/songs', async (req, res) => {
  try {
    const playlist = await Playlist.findById(req.params.playlistId);
    if (!playlist) {
      return res.status(404).json({ message: "Playlist not found" });
    }
    playlist.songs.push(req.body);
    await playlist.save();
    res.status(201).json({ message: "Song added to playlist", song: req.body });
  } catch (error) {
    res.status(400).json({ message: "Error adding song to playlist", error: error.message });
  }
});

// Remove a song from a playlist
app.delete('/api/playlists/:playlistId/songs/:songId', async (req, res) => {
  try {
    const playlist = await Playlist.findById(req.params.playlistId);
    if (!playlist) {
      return res.status(404).json({ message: "Playlist not found" });
    }
    playlist.songs = playlist.songs.filter(song => song._id.toString() !== req.params.songId);
    await playlist.save();
    res.json({ message: "Song removed from playlist" });
  } catch (error) {
    res.status(500).json({ message: "Error removing song from playlist", error: error.message });
  }
});

// Search for playlists, songs, or users
app.get('/api/search', async (req, res) => {
  const { query, type } = req.query;
  try {
    let results;
    switch (type) {
      case 'playlist':
        results = await Playlist.find({ name: new RegExp(query, 'i') });
        break;
      case 'song':
        results = await Playlist.find({ 'songs.name': new RegExp(query, 'i') }, { 'songs.$': 1 });
        break;
      case 'user':
        results = await User.find({ $or: [{ name: new RegExp(query, 'i') }, { username: new RegExp(query, 'i') }] }).select('-password');
        break;
      default:
        return res.status(400).json({ message: "Invalid search type" });
    }
    res.json(results);
  } catch (error) {
    res.status(500).json({ message: "Error searching", error: error.message });
  }
});



app.post('/api/friends/add', async (req, res) => {
  const { userId, friendId } = req.body;

  if (!userId || !friendId) {
    return res.status(400).json({ message: "User ID and Friend ID are required" });
  }

  try {
    const user = await User.findById(userId);
    const friend = await User.findById(friendId);

    if (!user || !friend) {
      return res.status(404).json({ message: "User not found" });
    }

    // Update friend lists
    if (user.friends.includes(friendId)) {
      return res.status(400).json({ message: "Already friends" });
    }

    user.friends.push(friendId);
    friend.friends.push(userId);

    await user.save();
    await friend.save();

    res.status(200).json({ message: "Friend added successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error adding friend", error: error.message });
  }
});




// Get all playlists for a specific user
app.get('/api/users/:userId/playlists', async (req, res) => {
  try {
    const userId = req.params.userId;
    const playlists = await Playlist.find({ userId: userId });

    if (!playlists.length) {
      return res.status(404).json({ message: "No playlists found for this user" });
    }

    res.json(playlists);
  } catch (error) {
    res.status(500).json({ message: "Error fetching playlists", error: error.message });
  }
});


// Friend/Unfriend route
app.post('/api/users/:userId/friends/:friendId', async (req, res) => {
  const { userId, friendId } = req.params;
  const user = await User.findById(userId);
  const friend = await User.findById(friendId);

  if (!user || !friend) {
    return res.status(404).json({ message: "User not found" });
  }

  // Concurrency control using locks (for thread safety)
  const lock = new Mutex();
  await lock.acquire();

  try {
    if (user.friends.includes(friendId)) {
      user.friends.pull(friendId);
      friend.friends.pull(userId);
    } else {
      user.friends.push(friendId);
      friend.friends.push(userId);
    }

    await user.save();
    await friend.save();

    res.status(200).json({ message: 'Friend status updated' });
  } catch (error) {
    res.status(500).json({ message: 'Error updating friends' });
  } finally {
    lock.release();
  }
});


// Get all users
app.get('/api/users', async (req, res) => {
  try {
    const users = await User.find().select('-password'); // Exclude passwords
    res.json(users);
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ message: "Error fetching users", error: error.message });
  }
});


// Serve static files from the 'frontend/public' directory
app.use(express.static(path.join(__dirname, '../frontend/public')));

// Catch-all route to serve index.html for any non-API requests
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/public', 'index.html'));
});


// Start the server
const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
