# IMY220Project
IMY220 Project (UP) u23616815



docker build -t tune-union-app .
docker run -p 5000:5000 --name tune-union-app-container tune-union-app
